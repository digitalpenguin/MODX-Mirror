<?php
$_lang['mirror.directoryNotCreated'] = 'Directory [[+path]] was not created';
$_lang['mirror.fileNotChanged'] = 'File [[+file]] was not changed';
$_lang['mirror.fileMoved'] = 'File [[+sourceFile]] was moved to [[+targetFile]]';
$_lang['mirror.fileDeleted'] = 'File [[+file]] was deleted';
$_lang['mirror.eventNotAttached'] = 'Event [[+event]] was not attached to plugin [[+plugin]]';
$_lang['mirror.objectNotSaved'] = 'Object of class [[+class]] with name [[+name]] was not saved';
$_lang['mirror.alreadyRunning'] = 'Another instance of Mirror is already running';
$_lang['mirror.categoryTruncated'] = 'Categories tree was truncated for category with ID [[+category]]';
$_lang['mirror.categoryTreeTruncated'] = 'Categories tree [[+category]] was truncated';